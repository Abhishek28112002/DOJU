export {default} from './ForgotPasswordScreen';
